function getData(msg){
console.log(msg);

}

var msg='hello world';

getData(msg);